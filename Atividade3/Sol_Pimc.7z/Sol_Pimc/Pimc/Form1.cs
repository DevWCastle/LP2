﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {

        double peso, altura, imc;
        string classificacao;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {


            imc = peso/(altura * altura) ;
            imc = Math.Round(imc, 1);

            if (imc < 18.5) { classificacao = "Magreza"; }
            else if (imc >= 18.5 && imc <= 24.9) { classificacao = "Normal"; }
            else if (imc >= 25.0 && imc <= 29.9) { classificacao = "Sobrepeso"; }
            else if (imc >= 30.0 && imc <= 39.9) { classificacao = "Obesidade (Grau II)"; }
            else { classificacao = "Obesidade Grave (Grau III)"; }

            txtbIMC.Text = imc.ToString();
            MessageBox.Show("Classificação: " + classificacao);
            
            

        }

        private void mskdxAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskdxAltura.Text, out altura) || altura <= 0)
            {

                errorProvider2.SetError(mskdxAltura, "Digite um número valido");
                mskdxAltura.Focus();

            }
            else
            {
                errorProvider2.Clear();
            }


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskdxAltura.Text = mskdxPesoAtual.Text = txtbIMC.Text = "";
            errorProvider1.Clear();
            errorProvider2.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja reamente sair?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) { 
                this.Close();
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          
        }

        private void mskdxPesoAtual_Validated(object sender, EventArgs e)
        {

            if (!Double.TryParse(mskdxPesoAtual.Text, out peso) || peso <= 0){

                errorProvider1.SetError(mskdxPesoAtual, "Digite um número valido");
                mskdxPesoAtual.Focus();

            }
            else
            {
                errorProvider1.Clear();
            }
            

           

       

        }
    }
}
