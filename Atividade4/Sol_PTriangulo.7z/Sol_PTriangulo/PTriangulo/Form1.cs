﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {

        int LadoA, LadoB, LadoC;

        private void txtA_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtA.Text, out LadoA))
            {
                MessageBox.Show("Digita certo caralho!!!!!!!!!!!!!!!!!");
                txtA.Focus();
            }
        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtB.Text, out LadoB))
            {
                MessageBox.Show("Digita certo caralho!!!!!!!!!!!!!!!!!");
                txtB.Focus();
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtC.Text, out LadoC))
            {
                MessageBox.Show("Digita certo caralho!!!!!!!!!!!!!!!!!");
                txtC.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (
                (
                 (LadoA > Math.Abs(LadoB - LadoC)) &&
                 (LadoA < LadoB + LadoC)
                ) &&
                (
                 (LadoB > Math.Abs(LadoA - LadoC)) &&
                 (LadoB < LadoA + LadoC)
                ) &&
                (
                    (LadoC > Math.Abs(LadoA - LadoB)) &&
                    (LadoC < LadoA + LadoB)
                )
                )
            {
                if (LadoA == LadoB && LadoB == LadoC)
                {
                    MessageBox.Show("O triângulo é Equilatero");
                }else if (LadoA == LadoB || LadoB == LadoC || LadoC == LadoA)
                {
                    MessageBox.Show("O triângulo é Isoceles");
                }
                else{
                  MessageBox.Show("O triângulo é Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Não é triângulo");
            }
        }
    }
}
