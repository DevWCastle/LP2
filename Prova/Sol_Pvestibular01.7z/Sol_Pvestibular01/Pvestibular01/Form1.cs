﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvestibular01
{
    public partial class Form1 : Form
    {

        int[,] cursos = new int[3, 5];
        int[] totAno = new int[3];
        int valAno, totGeral;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbxFinal.Items.Clear();
            valAno = totGeral = 0;
            for (int i = 0; i < totAno.Length; i++) { totAno[i] = 0; }
        }

        private void btnReceber_Click(object sender, EventArgs e) {

            totGeral = 0;
            for(int i = 0; i < 3; i++){
                totAno[i] = 0;
                for (int j = 0; j < 5; j++)
                {
                    string tot = Interaction.InputBox($"Digite o total do curso {i + 1}, do ano {j + 1}");

                    if (!int.TryParse(tot, out valAno) || valAno < 0)
                    {
                        j--;
                        MessageBox.Show("Valor Inválido! Digite um número positivo!");
                    }
                    else
                    {
                        cursos[i, j] = valAno;
                        totAno[i] += valAno;
                    }

                }

                totGeral += totAno[i];
            }


            lbxFinal.Items.Add($"\n");

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 5; j++)
                {
                    lbxFinal.Items.Add($"\n Total do curso {i + 1} do ano {j + 1}: {cursos[i, j]}");
                }

                lbxFinal.Items.Add($"\n TOTAL CURSO {i + 1}: {totAno[i]}");

                lbxFinal.Items.Add($"--------------------------------------- \n");

            }

            lbxFinal.Items.Add($"\nTOTAL GERAL: {totGeral}");
            lbxFinal.Items.Add($"\n");



        }
    }
}
