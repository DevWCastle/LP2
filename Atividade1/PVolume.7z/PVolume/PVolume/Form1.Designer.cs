﻿namespace PVolume
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcular = new System.Windows.Forms.Button();
            this.labelRaio = new System.Windows.Forms.Label();
            this.txtbRaio = new System.Windows.Forms.TextBox();
            this.btnFechar = new System.Windows.Forms.Button();
            this.txtbAltura = new System.Windows.Forms.TextBox();
            this.txtbVolume = new System.Windows.Forms.TextBox();
            this.labelAltura = new System.Windows.Forms.Label();
            this.labelVolume = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(88, 278);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(231, 71);
            this.btnCalcular.TabIndex = 0;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // labelRaio
            // 
            this.labelRaio.AutoSize = true;
            this.labelRaio.Location = new System.Drawing.Point(186, 74);
            this.labelRaio.Name = "labelRaio";
            this.labelRaio.Size = new System.Drawing.Size(42, 20);
            this.labelRaio.TabIndex = 1;
            this.labelRaio.Text = "Raio";
            // 
            // txtbRaio
            // 
            this.txtbRaio.Location = new System.Drawing.Point(280, 68);
            this.txtbRaio.Name = "txtbRaio";
            this.txtbRaio.Size = new System.Drawing.Size(434, 26);
            this.txtbRaio.TabIndex = 2;
            this.txtbRaio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbRaio_KeyPress);
            this.txtbRaio.Validated += new System.EventHandler(this.txtbRaio_Validated);
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(615, 278);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(231, 71);
            this.btnFechar.TabIndex = 3;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // txtbAltura
            // 
            this.txtbAltura.Location = new System.Drawing.Point(280, 137);
            this.txtbAltura.Name = "txtbAltura";
            this.txtbAltura.Size = new System.Drawing.Size(434, 26);
            this.txtbAltura.TabIndex = 4;
            this.txtbAltura.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbAltura_KeyPress);
            this.txtbAltura.Validated += new System.EventHandler(this.txtbAltura_Validated);
            // 
            // txtbVolume
            // 
            this.txtbVolume.Location = new System.Drawing.Point(280, 196);
            this.txtbVolume.Name = "txtbVolume";
            this.txtbVolume.ReadOnly = true;
            this.txtbVolume.Size = new System.Drawing.Size(434, 26);
            this.txtbVolume.TabIndex = 5;
            // 
            // labelAltura
            // 
            this.labelAltura.AutoSize = true;
            this.labelAltura.Location = new System.Drawing.Point(186, 140);
            this.labelAltura.Name = "labelAltura";
            this.labelAltura.Size = new System.Drawing.Size(51, 20);
            this.labelAltura.TabIndex = 6;
            this.labelAltura.Text = "Altura";
            // 
            // labelVolume
            // 
            this.labelVolume.AutoSize = true;
            this.labelVolume.Location = new System.Drawing.Point(186, 202);
            this.labelVolume.Name = "labelVolume";
            this.labelVolume.Size = new System.Drawing.Size(63, 20);
            this.labelVolume.TabIndex = 7;
            this.labelVolume.Text = "Volume";
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(352, 278);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(231, 71);
            this.btnLimpar.TabIndex = 8;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(880, 485);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.labelVolume);
            this.Controls.Add(this.labelAltura);
            this.Controls.Add(this.txtbVolume);
            this.Controls.Add(this.txtbAltura);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.txtbRaio);
            this.Controls.Add(this.labelRaio);
            this.Controls.Add(this.btnCalcular);
            this.Name = "Form1";
            this.Text = "Calculo de Volume";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label labelRaio;
        private System.Windows.Forms.TextBox txtbRaio;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.TextBox txtbAltura;
        private System.Windows.Forms.TextBox txtbVolume;
        private System.Windows.Forms.Label labelAltura;
        private System.Windows.Forms.Label labelVolume;
        private System.Windows.Forms.Button btnLimpar;
    }
}

