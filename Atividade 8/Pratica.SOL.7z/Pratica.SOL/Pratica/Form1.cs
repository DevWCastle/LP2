﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] numeros = new int[20];


            for (int i = 0; i < numeros.Length; i++)
            {
                string entrada = Interaction.InputBox($"Digite o {i + 1}º número inteiro:", "Entrada de Dados");


                if (int.TryParse(entrada, out int valor))
                {
                    numeros[i] = valor;
                }
                else
                {
                    MessageBox.Show("Valor inválido! Tente novamente.");
                    i--;
                }
            }


            Array.Reverse(numeros);


            string resultado = "Números em ordem inversa:\n";
            foreach (int n in numeros)
            {
                resultado += n + "\n";
            }

            MessageBox.Show(resultado, "Resultado");
        }

        private void ex2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList()
            {
                "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais"
            };

            alunos.Remove("Otávio");

            string resultado = "Lista de alunos (sem Otávio):\n";
            foreach (string nome in alunos)
            {
                resultado += nome + "\n";
            }

            MessageBox.Show(resultado, "Resultado");
        }

        private void ex3_Click(object sender, EventArgs e)
        {
            const int QTD_ALUNOS = 20;
            const int QTD_NOTAS = 3;
            double[,] notas = new double[QTD_ALUNOS, QTD_NOTAS];


            for (int i = 0; i < QTD_ALUNOS; i++)
            {
                for (int j = 0; j < QTD_NOTAS; j++)
                {
                    bool entradaValida = false;
                    double nota = 0;

                    while (!entradaValida)
                    {
                        string entrada = Interaction.InputBox(
                            $"Digite a nota {j + 1} do aluno {i + 1} (0 a 10):",
                            "Entrada de Notas");

                        if (double.TryParse(entrada, out nota) && nota >= 0 && nota <= 10)
                        {
                            entradaValida = true;
                            notas[i, j] = nota;
                        }
                        else
                        {
                            MessageBox.Show("Valor inválido! Digite um número entre 0 e 10.");
                        }
                    }
                }
            }

            string resultado = "Médias dos alunos:\n";

            for (int i = 0; i < QTD_ALUNOS; i++)
            {
                double soma = 0;
                for (int j = 0; j < QTD_NOTAS; j++)
                {
                    soma += notas[i, j];
                }

                double media = soma / QTD_NOTAS;
                resultado += $"Aluno {i + 1}: média = {media:F1}\n";
            }

            MessageBox.Show(resultado, "Resultados");


        }

        private void ex4_Click(object sender, EventArgs e)
        {
            Ex4 ex4 = new Ex4();
            ex4.Show();
        }

        private void ex5_Click(object sender, EventArgs e)
        {
            Ex5 ex5 = new Ex5();
            ex5.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if((MessageBox.Show("Realmente quer fechar?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question))==DialogResult.Yes){
                Close();
            } else
            {

            }
           

        }
    }
}


