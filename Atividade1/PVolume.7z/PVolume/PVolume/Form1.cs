﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Deseja realmente Fechar?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            
            if ( resultado == DialogResult.Yes)
                this.Close();

        }

        private void txtbAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtbAltura.Text, out altura) || (altura <= 0))
            {
                txtbAltura.Text = "";
                MessageBox.Show("Atura Invalida");
                txtbAltura.Focus();
            }
           
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtbRaio.Text = txtbAltura.Text = txtbVolume.Text = "";
            raio = altura = volume = 0;
        }

        private void txtbRaio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13) {
                txtbAltura.Focus();
            }
        }

        private void txtbAltura_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                btnCalcular.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtbRaio.Text, out raio) || (raio <= 0))
            {
                txtbRaio.Text = "";
                MessageBox.Show("Raio Invalido");
                txtbRaio.Focus();
            }
            else if (!Double.TryParse(txtbAltura.Text, out altura) || (altura <= 0))
            {
                txtbAltura.Text = "";
                MessageBox.Show("Atura Invalida");
                txtbAltura.Focus();
            }
            else
            {
                volume = Math.Pow(raio, 2) * Math.PI * altura;
                txtbVolume.Text = volume.ToString("N2") + " m2";
            }

        }

        private void txtbRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtbRaio.Text, out raio) || (raio <= 0)) {
                txtbRaio.Text = "";
                MessageBox.Show("Raio Invalido");
                txtbRaio.Focus();
            }
            
            
        }
    }
}
